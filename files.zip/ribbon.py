"""Market ribbon: index tiles with sparklines, like the strip atop Yahoo Finance.

Each equity-index tile shows, in order of preference:
  1. the index itself, while the regular US session is open;
  2. the matching futures contract, if the index is closed but futures are trading;
  3. the index at its last close, if both are closed.
Commodity, yield and volatility tiles simply show their latest data.
"""
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta, timezone
from datetime import time as dtime
from zoneinfo import ZoneInfo

import pandas as pd
import yfinance as yf
from flask import Blueprint, jsonify

bp = Blueprint("ribbon", __name__)

# name/symbol = the index; fut/fut_name = the futures shown when the index is closed.
TILES = [
    {"name": "S&P 500", "symbol": "^GSPC", "fut": "ES=F", "fut_name": "S&P futures"},
    {"name": "Dow", "symbol": "^DJI", "fut": "YM=F", "fut_name": "Dow futures"},
    {"name": "Nasdaq", "symbol": "^IXIC", "fut": "NQ=F", "fut_name": "Nasdaq futures"},
    {"name": "Russell 2000", "symbol": "^RUT", "fut": "RTY=F", "fut_name": "Russell futures"},
    {"name": "VIX", "symbol": "^VIX"},
    {"name": "10-yr yield", "symbol": "^TNX"},
    {"name": "Gold", "symbol": "GC=F"},
    {"name": "Crude oil", "symbol": "CL=F"},
]

CACHE_TTL = 60
FRESH_MINUTES = 30      # a latest bar older than this means the market isn't trading
MAX_POINTS = 60

_cache = {"at": 0.0, "data": None}
_lock = threading.Lock()


def regular_session_now():
    now = datetime.now(ZoneInfo("America/New_York"))
    return now.weekday() < 5 and dtime(9, 30) <= now.time() < dtime(16, 0)


def intraday(symbol, window):
    """Recent 5-minute closes. window='day' keeps the last trading date,
    window='24h' keeps the last 24 hours (futures sessions span midnight)."""
    df = yf.Ticker(symbol).history(period="5d", interval="5m")
    if df is None or df.empty or "Close" not in df:
        return pd.Series(dtype=float)
    s = df["Close"].dropna()
    if s.empty:
        return s
    if window == "day":
        dates = s.index.date
        return s[dates == dates[-1]]
    return s[s.index >= s.index[-1] - timedelta(hours=24)]


def is_fresh(s):
    if s.empty:
        return False
    age = datetime.now(timezone.utc) - s.index[-1].to_pydatetime()
    return age.total_seconds() < FRESH_MINUTES * 60


def make_tile(name, symbol, s, mode):
    if s.empty:
        raise ValueError("no data")
    price = float(s.iloc[-1])
    prev = None
    try:
        prev = float(yf.Ticker(symbol).fast_info["previous_close"])
    except Exception:
        pass
    if not prev:
        prev = float(s.iloc[0])
    change = price - prev
    pct = change / prev * 100 if prev else 0.0

    pts = [round(float(v), 4) for v in s.tolist()]
    step = max(1, len(pts) // MAX_POINTS)
    sampled = pts[::step]
    if (len(pts) - 1) % step:
        sampled.append(pts[-1])
    return {
        "name": name, "symbol": symbol, "mode": mode,
        "price": round(price, 4), "change": round(change, 4), "pct": round(pct, 4),
        "prev": round(prev, 4), "points": sampled,
    }


def build_tile(item):
    sym, fut = item["symbol"], item.get("fut")
    try:
        if fut:
            idx = intraday(sym, "day")
            if regular_session_now() and is_fresh(idx):
                return make_tile(item["name"], sym, idx, "live")
            fs = intraday(fut, "24h")
            if is_fresh(fs):
                return make_tile(item["fut_name"], fut, fs, "futures")
            return make_tile(item["name"], sym, idx, "close")
        window = "day" if sym.startswith("^") else "24h"
        s = intraday(sym, window)
        return make_tile(item["name"], sym, s, "live" if is_fresh(s) else "close")
    except Exception:
        return {"name": item["name"], "symbol": sym, "error": True}


@bp.get("/api/ribbon")
def api_ribbon():
    with _lock:
        if _cache["data"] is not None and time.time() - _cache["at"] < CACHE_TTL:
            return jsonify(tiles=_cache["data"])
        with ThreadPoolExecutor(max_workers=8) as pool:
            tiles = list(pool.map(build_tile, TILES))
        if any(not t.get("error") for t in tiles):
            _cache.update(at=time.time(), data=tiles)
        return jsonify(tiles=tiles)
